/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP TABLE IF EXISTS `in_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_attempts` (
  `attempt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attempt_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempt_ip` text COLLATE utf8mb4_unicode_ci,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `attempt_time` bigint(20) NOT NULL,
  PRIMARY KEY (`attempt_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `in_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_categories` (
  `category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The category name',
  `category_slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Unique slug for category',
  `category_icon` tinytext COLLATE utf8mb4_unicode_ci,
  `category_order` int(10) unsigned NOT NULL DEFAULT '100' COMMENT 'Category order, this will be used for homepage listing',
  `category_feat_at_home` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'If enabled latest posts from this category will be shown on homepage',
  `created_at` bigint(20) NOT NULL DEFAULT '0',
  `updated_at` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `cat_slug` (`category_slug`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_categories` WRITE;
/*!40000 ALTER TABLE `in_categories` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `in_categories` VALUES (1,'Politics','politics','/site/uploads/2019/Oct/04/iconmonstr-building-35-48.png',2,1,1567672266,1570187954),(2,'Local','local','/site/uploads/2019/Oct/04/iconmonstr-map-8-48.png',3,1,1567672541,1570187962),(3,'International','international','/site/uploads/2019/Oct/04/iconmonstr-delivery-13-48.png',1,1,1567672574,1570187936),(4,'Finance','finance','/site/uploads/2019/Oct/04/iconmonstr-chart-6-48.png',4,1,1567672625,1570187972),(5,'Sports','sports','/site/uploads/2019/Oct/04/iconmonstr-soccer-1-32.png',6,1,1567672636,1570187980),(6,'Entertainment','entertainment','/site/uploads/2019/Oct/04/iconmonstr-party-15-32.png',7,1,1567672654,1570187990),(7,'Lifestyle','lifestyle','/site/uploads/2019/Oct/04/iconmonstr-glasses-13-32.png',8,1,1567673074,1570188004),(8,'Technology','technology','/site/uploads/2019/Oct/04/iconmonstr-battery-10-32.png',9,1,1567673155,1570188012),(9,'Science','science','/site/uploads/2019/Oct/04/iconmonstr-school-18-32.png',11,1,1567673167,1570188027),(10,'Health','health','/site/uploads/2019/Oct/04/iconmonstr-medical-6-32.png',12,1,1567673175,1570188035),(11,'Literature','literature','/site/uploads/2019/Oct/04/iconmonstr-book-17-32.png',10,1,1567673277,1570188018);
/*!40000 ALTER TABLE `in_categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_content` (
  `content_id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `content_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_slug` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_author` int(11) NOT NULL,
  `content_body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `content_size` bigint(20) DEFAULT '0',
  `content_mimetype` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_meta` text COLLATE utf8mb4_unicode_ci,
  `created_at` bigint(20) NOT NULL DEFAULT '0',
  `updated_at` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`),
  UNIQUE KEY `content_slug` (`content_slug`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_content` WRITE;
/*!40000 ALTER TABLE `in_content` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `in_content` VALUES (1,'About Us','about-us',1,'<p>There once was a story about a man who could turn invisible. I thought it was only a story... until it happened to me. Ok, so here\'s how it works: there\'s this stuff called <a href=\"#\">Quicksilver that can</a> bend light. Some scientist made it into a synthetic gland, and that\'s where I came in. See, I was facing life in prison and they were looking for a human experiment. So, we made a deal. They put the gland in my brain; I walk free. The operation was a success... but that\'s where everything started to go wrong.</p>\r\n\r\n<p>Marshall, Will, and Holly on a routine expedition, met the greatest earthquake ever known. High on the rapids, it struck their tiny raft! And plunged them down a thousand feet below... to the Land of the Lost! Lost! <a href=\"#\">Lost! Lost! Lost!</a></p>\r\n\r\n<p>My name is Rhoda Morgenstern. I was born in the Bronx, New York in December of 1941. I\'ve always felt responsible for World War II. The first thing I remember liking that liked me back was food. I had a bad puberty; it lasted seventeen years. I\'m a high school graduate. I went to art school. My entrance exam was on a book of matches. I decided to move out of the house when I was twenty-four. My mother still refers to this as the time I ran away from home. Eventually, I ran to Minneapolis, where it\'s cold and I figured I\'d keep better. Now I\'m back in Manhattan. New York, this is <a href=\"#\">your last chance!</a></p>\r\n\r\n<p>There\'s a holdout in the Bronx, Brooklyn\'s broken out in fights. There\'s a traffic jam in <a href=\"#\">Harlem that\'s backed</a> up to Jackson Heights. There\'s a Scout troop short a child, Khrushchev\'s due at Idelwyld... Car 54, where are you?</p>\r\n\r\n<p>Moon over Parma, bring <a href=\"#\">my love to</a> me tonight. Guide her to Cleveland, underneath your silvery light. We\'re going bowlin\' so don\'t lose her in Solon. Moon over Parma, tonight!</p>\r\n\r\n','','page',0,NULL,NULL,1545883269,1556338147),(2,'Contact Us','contact-us',1,'<p>Yes, this is a generic contact us page, it may contain email links,&nbsp; or a slug based <strong>pages/contact-us.php</strong> template, idk. anything is possible</p>','','page',0,NULL,NULL,1551429694,1555918695),(3,'Terms & Conditions','terms',1,'<p>Roger Ramjet and his Eagles, fighting for our freedom. Fly through and in outer space, not to <a href=\"#\">join him but</a> to beat him! When Ramjet takes a Proton pill, the crooks begin to worry. They cant escape their awful fate from Protons mighty fury! Come and join us all you kids for lots of fun and laughter, as Roger Ramjet and his men get all the crooks they\'re after! Roger Ramjet he\'s our man, hero of our nation. For his adventure just be sure and stay tuned to this station!</p>\r\n\r\n<p>What walks down stairs, alone or in pairs, and makes a slinkity sound? A spring, a spring, a marvelous thing, everyone knows it\'s Slinky. It\'s Slinky, it\'s Slinky, for fun it\'s a wonderful toy. It\'s Slinky, it\'s Slinky, it\'s fun for a girl or a boy. It\'s fun for a <a href=\"#\">girl or boy!</a></p>\r\n\r\n<p>Look for the Union Label when you are <a href=\"#\">buying a coat,</a> dress, or blouse. Remember, somewhere our union\'s sewing, our wages going to feed the kids, and run the house. We work hard, but who\'s complaining. Thanks to the I.L.G. we\'re paying our way. So always look for the Union Label. It means we\'re able to make it in the U.S.A.!</p>\r\n\r\n<p>My kinda people, my kinda place. There\'s something special about this place. Got no reason to stray too far, \'cause it\'s all right here in my own backyard! This is a Burger King town, it\'s made just for me! This is a Burger King town, we know how burgers should be! Right up the road, left at the sign. My way, your way, one at a time, hot off <a href=\"#\">the fire with</a> anything on it! And don\'t it feel good when it\'s just how you want it? This is a Burger King town, it\'s made just for me! This is a Burger King town, we know how burgers should be!</p>\r\n\r\n<p>I bet we been together for a million years, And I bet we\'ll be together for a million more. Oh, It\'s like I started breathing on the night we kissed, and I can\'t remember what I ever did before. What would we do baby, without us? What would we do baby, without us? And there ain\'t no nothing we can\'t love each other through. What would we do baby, without us? Sha <a href=\"#\">la la la.</a></p>\r\n\r\n','','page',0,NULL,NULL,1556337990,1556337990),(4,'iconmonstr-delivery-13-48',NULL,1,'','2019/Oct/04/iconmonstr-delivery-13-48.png','attachment',16867,'image/png',NULL,1570187932,1570187932),(5,'iconmonstr-building-35-48',NULL,1,'','2019/Oct/04/iconmonstr-building-35-48.png','attachment',15428,'image/png',NULL,1570187950,1570187950),(6,'iconmonstr-map-8-48',NULL,1,'','2019/Oct/04/iconmonstr-map-8-48.png','attachment',16446,'image/png',NULL,1570187961,1570187961),(7,'iconmonstr-chart-6-48',NULL,1,'','2019/Oct/04/iconmonstr-chart-6-48.png','attachment',15619,'image/png',NULL,1570187970,1570187970),(8,'iconmonstr-soccer-1-32',NULL,1,'','2019/Oct/04/iconmonstr-soccer-1-32.png','attachment',1546,'image/png',NULL,1570187979,1570187979),(9,'iconmonstr-party-15-32',NULL,1,'','2019/Oct/04/iconmonstr-party-15-32.png','attachment',1126,'image/png',NULL,1570187989,1570187989),(10,'iconmonstr-glasses-13-32',NULL,1,'','2019/Oct/04/iconmonstr-glasses-13-32.png','attachment',837,'image/png',NULL,1570188003,1570188003),(11,'iconmonstr-battery-10-32',NULL,1,'','2019/Oct/04/iconmonstr-battery-10-32.png','attachment',412,'image/png',NULL,1570188011,1570188011),(12,'iconmonstr-book-17-32',NULL,1,'','2019/Oct/04/iconmonstr-book-17-32.png','attachment',671,'image/png',NULL,1570188017,1570188017),(13,'iconmonstr-school-18-32',NULL,1,'','2019/Oct/04/iconmonstr-school-18-32.png','attachment',1930,'image/png',NULL,1570188026,1570188026),(14,'iconmonstr-medical-6-32',NULL,1,'','2019/Oct/04/iconmonstr-medical-6-32.png','attachment',1012,'image/png',NULL,1570188034,1570188034),(15,'inbefore-logo',NULL,1,'','2019/Oct/05/inbefore-logo.png','attachment',22537,'image/png',NULL,1570261209,1570261209);
/*!40000 ALTER TABLE `in_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_engines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_engines` (
  `engine_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `engine_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A short name for the engine',
  `engine_cse_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Google CSE ID for the engine.',
  `engine_is_image` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Choose if the result type is image or not',
  `engine_show_thumb` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Select if thumbnails will be shown when if available (web result only)',
  `created_at` bigint(20) NOT NULL DEFAULT '0',
  `updated_at` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`engine_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_engines` WRITE;
/*!40000 ALTER TABLE `in_engines` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `in_engines` VALUES (1,'Web','34eef687ce269487c',0,0,1567321257,1580814530),(3,'Videos','530b5e7ca4f8045d4',0,1,1567321259,1580814558),(4,'News','b16521454a1884f6a',0,1,1567321259,1567321259),(5,'Torrents','6ff7034d0894868ee',0,0,1567321259,1592295317),(6,'Subtitles','93314d2add702dbab',0,0,1567321259,1567321259),(2,'Images','954a56c1e00db57aa',1,0,1567321258,1592295337);
/*!40000 ALTER TABLE `in_engines` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_feeds` (
  `feed_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `feed_category_id` int(10) NOT NULL COMMENT '@skip',
  `feed_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Feed name, for reference purpose.',
  `feed_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'URL to the feed.',
  `feed_logo_url` text COLLATE utf8mb4_unicode_ci,
  `feed_priority` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Feed priority, lower numbers will be executed early',
  `feed_max_items` int(10) NOT NULL DEFAULT '0' COMMENT 'Maximum number of items to fetch at each refresh, set this to 0 to fetch all the items.',
  `feed_fulltext_selector` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'HTML selector for fulltext ',
  `feed_fetch_fulltext` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'If enabled we will attempt to fetch full text otherwise just the excerpt.',
  `feed_auto_update` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Choose if the feed would be auto updated via cron job',
  `feed_ignore_without_image` tinyint(1) NOT NULL DEFAULT '1',
  `feed_last_refreshed` int(20) NOT NULL DEFAULT '0' COMMENT '@skip',
  `feed_content_maxlength` int(10) NOT NULL DEFAULT '0',
  `feed_required_content_length` int(10) DEFAULT '0',
  `feed_required_keywords` text COLLATE utf8mb4_unicode_ci,
  `feed_keyword_mode` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` bigint(20) NOT NULL DEFAULT '0',
  `updated_at` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`feed_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_feeds` WRITE;
/*!40000 ALTER TABLE `in_feeds` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `in_feeds` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_options` (
  `option_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_value` text COLLATE utf8mb4_unicode_ci,
  `option_autoload` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `options_name_unique` (`option_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_options` WRITE;
/*!40000 ALTER TABLE `in_options` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `in_options` VALUES ('active_plugins','[\"sitemap\",\"instant-answer\"]',1),('active_theme','default',1),('ad_unit_1','<div class=\"dummy-ad\" style=\"min-height:200px\">\r\n<h5>RIGHT SIDEBAR TOP AD</h5>\r\n</div>',0),('ad_unit_2','<div class=\"dummy-ad mt-3 mx-0\" style=\"min-height:300px;max-width:160px\">\r\n<h5>LEFT SIDEBAR AD</h5>\r\n<p>Hidden in mobile, Best for skyscrapers.</p>\r\n</div>',0),('ad_unit_3','<!--<div class=\"dummy-ad mt-3\" style=\"min-height:60px;max-width:468px;\">\r\n<h5>468x60 AD AFTER 4 POSTS</h5>\r\n</div>-->',0),('captcha_enabled','0',0),('footer_scripts','',1),('google_recaptcha_secret_key','',0),('google_recaptcha_site_key','',0),('header_scripts','',1),('site_description','inbefore is a automated news aggregator with Google CSE based search engine script that searches different portions of the web via Google Custom Search Engine.',1),('default_engine','1',0),('site_email','mirazmac@gmail.com',1),('site_locale','',0),('site_logo','/site/uploads/2019/Oct/05/inbefore-logo.png',1),('site_name','inbefore',1),('site_tagline','search engine, content portal, news aggretator',1),('smtp_auth_enabled','',0),('smtp_enabled','',0),('smtp_host','smtp.gmail.com',0),('smtp_password','',0),('smtp_port','587',0),('smtp_username','user@gmail.com',0),('timezone','Asia/Dhaka',1),('facebook_username','',0),('twitter_username','',0),('youtube_username','',0),('instagram_username','',0),('linkedin_username','',0),('facebook_app_secret','',0),('facebook_app_id','',0),('spark_cron_job_token','2076d6e05e5675f07aa6',0),('hello_world_name','OK',0),('latest_posts_count','18',0),('category_posts_count','50',0),('feed_redirection','0',0),('max_slider_items','10',0),('search_items_count','20',0),('disqus_url','',0),('disqus_enabled','0',0),('popular_posts_count','5',0),('ad_unit_8','<div class=\"dummy-ad mt-1 mb-4\" style=\"min-height:200px;max-width:200px\">\r\n<h5>ARTICLE AD BOX</h5>\r\n</div>',0),('ad_unit_5','<div class=\"dummy-ad mt-1 mb-0\" style=\"min-height:200px\">\r\n<h5>SEARCH SIDEBAR AD</h5>\r\n</div>',0),('ad_unit_6','<div class=\"dummy-ad mt-1 mb-0\" style=\"min-height:60px\">\r\n<h5>PRE SEARCH RESULTS AD</h5>\r\n</div>',0),('auto_delete_posts_after','0',0),('ad_unit_4','<div class=\"dummy-ad\" style=\"min-height:200px\">\r\n<h5>RIGHT SIDEBAR BOTTOM AD</h5>\r\n</div>',0),('ad_unit_7','<div class=\"dummy-ad mt-1 mb-4\" style=\"min-height:60px\">\r\n<h5>POST SEARCH RESULTS AD</h5>\r\n</div>',0),('use_search_as_default','0',0),('enable_search_ads','0',0),('trends_region','US',0),('enable_yt_downloader','0',0),('enable_registration','0',0),('related_posts_count','3',0),('fb_comments_enabled','0',0),('site_language','en_US',0),('default_theme_custom_css','',0),('single_page_layout','single-with-sidebar',0),('sitemap_links_per_page','1000',0),('rss_items_per_page','50',0),('iframe_allowed_domains','youtube.com\nyoutu.be\nplayer.twitch.tv\nplayer.vimeo.com\ndailymotion.com',0),('search_links_newwindow','1',0),('safesearch_status','off',0),('rss_show_fulltext','0',0),('default_thumb_url','/site/assets/img/broken.gif',0),('popular_posts_interval','all-time',0),('rewriter_enabled_feed','{\"30\":\"English\"}',0);
/*!40000 ALTER TABLE `in_options` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_permissions` (
  `perm_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `perm_desc` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`perm_id`),
  UNIQUE KEY `perm_desc` (`perm_desc`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_permissions` WRITE;
/*!40000 ALTER TABLE `in_permissions` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `in_permissions` VALUES (1,'access_dashboard'),(2,'add_user'),(3,'edit_user'),(4,'delete_user'),(5,'add_role'),(6,'edit_role'),(7,'delete_role'),(8,'change_settings'),(9,'manage_plugins'),(10,'change_user_role'),(11,'manage_gallery'),(12,'manage_pages'),(13,'manage_themes'),(14,'access_gallery'),(15,'change_user_status'),(18,'manage_categories'),(17,'manage_engines'),(19,'manage_feeds'),(20,'manage_posts');
/*!40000 ALTER TABLE `in_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_posts` (
  `post_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_category_id` int(10) unsigned NOT NULL COMMENT '@skip',
  `post_feed_id` int(10) unsigned NOT NULL COMMENT '@skip',
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Title for the post',
  `post_author` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Anonymous',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Post body, HTML enabled',
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Post excerpt',
  `post_featured_image` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Featured image URL for the post',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'imported_post' COMMENT '@skip',
  `post_source` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Source link to the post',
  `post_hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of hits/views the post has recieved',
  `post_pubdate` bigint(20) NOT NULL DEFAULT '0' COMMENT '@skip',
  `created_at` bigint(20) NOT NULL DEFAULT '0',
  `updated_at` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_posts` WRITE;
/*!40000 ALTER TABLE `in_posts` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `in_posts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_role_perm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_role_perm` (
  `role_id` int(10) unsigned NOT NULL,
  `perm_id` int(10) unsigned NOT NULL,
  KEY `role_id` (`role_id`),
  KEY `perm_id` (`perm_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_role_perm` WRITE;
/*!40000 ALTER TABLE `in_role_perm` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `in_role_perm` VALUES (3,1),(1,20),(1,19),(1,17),(1,18),(1,15),(1,14),(1,13),(1,12),(1,11),(1,10),(1,9),(1,8),(1,7),(1,6),(1,5),(1,4),(1,3),(2,15),(2,12),(2,11),(2,3),(1,2),(2,2),(1,1),(2,1);
/*!40000 ALTER TABLE `in_role_perm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_roles` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_protected` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` bigint(20) DEFAULT '0',
  `updated_at` bigint(20) DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_roles` WRITE;
/*!40000 ALTER TABLE `in_roles` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `in_roles` VALUES (1,'Administrator',1,1543473719,1585127297),(2,'Moderator',1,1543473766,1567320523),(3,'User',1,1543473780,1544779012);
/*!40000 ALTER TABLE `in_roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_tokens` (
  `token_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_expires` bigint(20) NOT NULL,
  PRIMARY KEY (`token_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_tokens` WRITE;
/*!40000 ALTER TABLE `in_tokens` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `in_tokens` VALUES (1,1,'COOKIE','a4c8d115645fcee6565a2f919285953ed8e3b6069b1dba91da491d3e542c',1595832470),(2,1,'COOKIE','4a7c2e3c48014ca54f9e7766eaba9e61fdf5b92b6e94b461f72471a55eb6',1596265219),(3,1,'COOKIE','591aa654ddf4d1d36ba76bd2c0b197346b188c6991fd7ca1c4022574f7b3',1596732368),(9,1,'COOKIE','9ac04c98f75cc1dc6391ce630ca6756c98e8bd8c1787da026844a73d7870',1597740260),(6,3,'EMAIL','f778ea808b64c7a19f2a1dedefba301e4128fed6',1582301319),(10,1,'COOKIE','23d60206b13ca3f3d900dd681f5fcd78cdff930fa67d010e7642ab1b3eb3',1597817156),(11,1,'COOKIE','c8a0644136bbd9eaf40b107ec7fa99b0f04b32c832fd63a85ad0e4cf04e3',1599034938),(13,1,'COOKIE','ef3f9f1f8d8e8effccee75bbf5ba7c20a82512befa14eca73f623a6799ac',1603275727),(14,1,'COOKIE','3e0974c62d4274ef58006a3148b88f18a3fb3fce1a0f6317dab21089ee00',1604486748),(15,1,'COOKIE','6c401c8178b233fe40662f382ed548ae37cde57b96fc7904d35f5effcd2f',1604736861),(16,1,'COOKIE','5acd4c771ad948e7701532908a94ab4f63fcc598e936801739369178af4e',1604743292),(17,1,'COOKIE','86cf94c112e1ef8f3525f2c37668b354a351c3d2176ec4c0bda67d99f76c',1604751166),(18,1,'COOKIE','13b37169b3208efc9678cb88b51d5b7eb22e8f8a14e9c5c73f5a45b6e71c',1604751210),(19,1,'COOKIE','1dc19bde5b69491b9a05fca2dd14d8e1a000117cd6be4f4877d31e678ded',1604822389),(20,1,'COOKIE','52b7920852320d44a50ce09c3b36ec71f13fe0803586d14591b0f8073b7e',1605009488),(21,1,'COOKIE','7d34fecf3f26bf7c6030e96eec497f41e12644c2e742add012bbcb2df1f1',1605445709),(24,1,'COOKIE','4ce320db2e0beb1a7f881462695ebfffe4a21df8ca4c10787a5892ef24bc',1606818310),(26,1,'COOKIE','7590c4eaf0a3d7a670534fd3ebe192277a16d30c3d60ca7d1249de43746f',1614065684),(27,1,'COOKIE','e51a5acbbbac32d38b072b7a0409ce493af440d766dcd1eee50d6bce82dc',1616225702),(28,1,'COOKIE','84680cc6916930590e46885a922aad7f89d1809229e9fca4ff15f5101d84',1617519614),(30,1,'COOKIE','7277d39b21ead65e061351cdc39b313a86195dd5c00db97bf811c2067a23',1620024744),(32,1,'COOKIE','c93974224fbc28e8c2bdfd723263b9dd466a1fd27f324c26c37fe5fd303e',1624199165);
/*!40000 ALTER TABLE `in_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

DROP TABLE IF EXISTS `in_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'user ID',
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user e-mail',
  `password` char(60) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'password hash',
  `username` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'unique username',
  `full_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'user''s legal name',
  `gender` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'user''s gender, 1 = male, 2 = female, 0 = non-binary',
  `avatar` text COLLATE utf8mb4_unicode_ci COMMENT 'user''s avatar url',
  `user_ip` text COLLATE utf8mb4_unicode_ci COMMENT 'user''s creation IP',
  `role_id` int(10) unsigned NOT NULL DEFAULT '3' COMMENT 'role ID of user',
  `is_blocked` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'user''s block status',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'whether the user is verifed or not',
  `last_seen` bigint(20) DEFAULT '0' COMMENT 'last activity timestamp',
  `created_at` bigint(20) NOT NULL DEFAULT '0' COMMENT 'when the row was created',
  `updated_at` bigint(20) DEFAULT '0' COMMENT 'when the row was last updated',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `in_users` WRITE;
/*!40000 ALTER TABLE `in_users` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `in_users` VALUES (1,'demo@mirazmac.com','$2y$10$IO.2achDkmjW/MldsAvDBuGdw08LVHxyQDlyzKgy/d2s7YgRGnZx2','demoadmin','John Doe',1,NULL,'127.0.0.1',1,0,1,1609423146,1532602768,1609423146);
/*!40000 ALTER TABLE `in_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

