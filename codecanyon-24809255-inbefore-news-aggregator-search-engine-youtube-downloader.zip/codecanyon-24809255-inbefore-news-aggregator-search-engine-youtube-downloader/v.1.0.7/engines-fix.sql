TRUNCATE `in_engines`;
INSERT INTO `in_engines` (`engine_id`, `engine_name`, `engine_cse_id`, `engine_is_image`, `engine_show_thumb`, `created_at`, `updated_at`) VALUES
(1, 'Web', '34eef687ce269487c', 0, 0, 1567321257, 1580814530),
(2, 'Images', '954a56c1e00db57aa', 1, 0, 1567321258, 1592295337),
(3, 'Videos', '530b5e7ca4f8045d4', 0, 1, 1567321259, 1580814558),
(4, 'News', 'b16521454a1884f6a', 0, 1, 1567321259, 1567321259),
(5, 'Torrents', '6ff7034d0894868ee', 0, 0, 1567321259, 1592295317),
(6, 'Subtitles', '93314d2add702dbab', 0, 0, 1567321259, 1567321259);
