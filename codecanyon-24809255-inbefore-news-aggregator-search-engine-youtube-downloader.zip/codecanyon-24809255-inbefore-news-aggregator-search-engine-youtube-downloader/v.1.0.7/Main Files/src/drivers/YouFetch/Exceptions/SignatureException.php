<?php

namespace MirazMac\YouFetch\Exceptions;

/**
* SignatureException
*
* @package MirazMac\YouFetch
*/
class SignatureException extends \Exception
{
}
