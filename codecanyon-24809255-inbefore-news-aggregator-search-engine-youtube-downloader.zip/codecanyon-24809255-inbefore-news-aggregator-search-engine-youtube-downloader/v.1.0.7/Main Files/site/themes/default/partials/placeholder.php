<div class="py-4 px-2">
    <div class="placeholder placeholder-paragraph"></div>
    <?php for ($i=0; $i < 6; $i++) : ?>
        <div class="placeholder placeholder-heading"></div>
        <div class="placeholder placeholder-sentence"></div>
        <div class="placeholder placeholder-sentence"></div>
        <div class="placeholder placeholder-sentence placeholder-sentence-last"></div>
    <?php endfor; ?>
</div>
